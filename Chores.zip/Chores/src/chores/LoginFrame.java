
package chores;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginFrame() {
        super("Login Screen");

        // Create components
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        // Layout components
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        // Add action listener to login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Check if login credentials are valid
                if (username.equals("no") && password.equals("you")) {
                    setVisible(false);
                    dispose();
                    new MainFrame();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid login credentials.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add panel to frame
        add(panel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginFrame();
    }
}

class MainFrame extends JFrame {
    public MainFrame() {
        super("Main Menu");

        // Create components
        JButton coinsButton = new JButton("Coins");
        JButton choresButton = new JButton("Chores");
        JButton shopButton = new JButton("Shop");

        // Layout components
        JPanel panel = new JPanel(new GridLayout(1, 3));
        panel.add(coinsButton);
        panel.add(choresButton);
        panel.add(shopButton);

        // Add action listeners to buttons
        coinsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CoinsFrame();
            }
        });

        choresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ChoresFrame();
            }
        });

        shopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ShopFrame();
            }
        });

        // Add panel to frame
        add(panel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

class CoinsFrame extends JFrame {
    public CoinsFrame() {
        super("Coins");

        // Create components
        JLabel label = new JLabel("This is the coins frame.");

        // Layout components
        JPanel panel = new JPanel();
        panel.add(label);

        // Add panel to frame
        add(panel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

class ChoresFrame extends JFrame {
    public ChoresFrame() {
        super("Chores");

        // Create components
        JLabel label = new JLabel("This is the chores frame.");

        // Layout components
        JPanel panel = new JPanel();
        panel.add(label);

        // Add panel to frame
        add(panel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

class ShopFrame extends JFrame {
    public ShopFrame()
            {
super("Shop");


// Create components
JLabel label = new JLabel("This is the shop frame.");

// Layout components
JPanel panel = new JPanel();
panel.add(label);

// Add panel to frame
add(panel);

// Set frame properties
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
pack();
setLocationRelativeTo(null);
setVisible(true);
}
}